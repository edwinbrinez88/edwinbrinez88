# Generador de Informes FUDRA12

Aplicación desarrollada en Python con Streamlit que permite cargar hasta 4 archivos PDF de evaluación mensual de unidades militares y generar automáticamente un informe resumen con el formato del Ejército Nacional.

## Cómo usar
1. Ejecuta: `streamlit run app.py`
2. Carga tus archivos PDF.
3. Revisa y descarga tu informe automático.

## Requisitos
- Python 3.8+
- Paquetes: `streamlit`, `PyMuPDF`

## Autor
SEÑOR BRIÑEZ – VIVA LA LIBERTAD CARAJO
