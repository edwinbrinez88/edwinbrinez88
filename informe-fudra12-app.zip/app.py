import streamlit as st
import fitz  # PyMuPDF
import re

st.set_page_config(page_title="Generador de Informes FUDRA12", layout="wide")

st.title("🪖 Generador Automático de Informes – FUDRA12")
st.markdown("Sube hasta 4 archivos PDF de calificación y genera un informe resumen.")

uploaded_files = st.file_uploader("📁 Cargar documentos PDF", type="pdf", accept_multiple_files=True)

def extraer_texto(pdf_file):
    texto = ""
    with fitz.open(stream=pdf_file.read(), filetype="pdf") as doc:
        for page in doc:
            texto += page.get_text()
    return texto

def extraer_calificaciones(texto):
    patron = r"(BADRA\d{2}|BADRE\d{2})[\s\S]{0,50}?(\d{1,3},\d{1,2}%)"
    matches = re.findall(patron, texto)
    resumen = {}
    for unidad, porcentaje in matches:
        porcentaje_limpio = float(porcentaje.replace(",", ".").replace("%", ""))
        resumen[unidad] = porcentaje_limpio
    return resumen

def generar_informe(resumen_total):
    informe = "# INFORME RESUMEN FUDRA12\n\n"
    informe += "## Evaluación Consolidada por Unidad\n\n"
    for unidad, calificacion in resumen_total.items():
        concepto = "Deficiente"
        if calificacion >= 91:
            concepto = "Superior a lo normal"
        elif calificacion >= 86:
            concepto = "Normal Alto"
        elif calificacion >= 81:
            concepto = "Normal Medio"
        elif calificacion >= 75:
            concepto = "Normal Bajo"
        elif calificacion >= 60:
            concepto = "Inferior a lo normal"
        informe += f"- **{unidad}**: {calificacion:.2f}% — *{concepto}*\n"
    informe += "\n---\n"
    informe += "*Informe generado automáticamente con base en los archivos cargados.*\n"
    return informe

if uploaded_files:
    resumen_global = {}
    for archivo in uploaded_files:
        texto = extraer_texto(archivo)
        resumen = extraer_calificaciones(texto)
        resumen_global.update(resumen)

    if resumen_global:
        informe_generado = generar_informe(resumen_global)
        st.success("✅ Informe generado correctamente")
        st.text_area("📝 Informe", informe_generado, height=400)

        st.download_button("📥 Descargar informe .txt", informe_generado, file_name="informe_FUDRA12.txt")
    else:
        st.warning("No se encontraron calificaciones en los archivos.")
